﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using School.Management.Core.Entities;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace School.Management.Data
{
    public class StudentRepository : Core.Repository.IStudentRepository
    {
        SqlConnection sqlConnection = null;
        public async Task<Student> Add(Student student)
        {
            try
            {
                string connectionString = "Server=DESKTOP-OUCK1GJ\\SQLEXPRESS;Database=SchoolManagement;Trusted_Connection=True;";

                // var connectionstring = ConfigurationManager.AppSettings["SqlConnection"];               
                sqlConnection = new SqlConnection(connectionString);
                await sqlConnection.OpenAsync();
                SqlCommand sqlcommand = new SqlCommand("CreateNewStudent", sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlcommand.Parameters.Add("@Name", SqlDbType.Text).Value = student.Name;
                sqlcommand.Parameters.Add("@Age", SqlDbType.Int).Value = student.Age;
                sqlcommand.Parameters.Add("@BirthDate", SqlDbType.DateTime).Value = student.Birthdate;

                var returnval = await sqlcommand.ExecuteReaderAsync();
                await sqlConnection.CloseAsync();
            }
            catch(Exception ex)
            {

            }
            return student;
        }
        public async Task<Student> Delete(int id)
        {
           
            try
            {
                string connectionString = "Server=DESKTOP-OUCK1GJ\\SQLEXPRESS;Database=SchoolManagement;Trusted_Connection=True;";

                // var connectionstring = ConfigurationManager.AppSettings["SqlConnection"];               
                sqlConnection = new SqlConnection(connectionString);
                await sqlConnection.OpenAsync();
                SqlCommand sqlcommand = new SqlCommand("DeleteStudent", sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlcommand.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                var p = await sqlcommand.ExecuteReaderAsync();
                await sqlConnection.CloseAsync();
                return new Student();
            }           
            catch (Exception ex)
            {
                return null;
            }
        }
        public void Dispose()
        {
           
        }

        public async Task<List<Student>> GetAllAsync(int id)
        {
            // Get all students 
            try
            {

                string connectionString = "Server=DESKTOP-OUCK1GJ\\SQLEXPRESS;Database=SchoolManagement;Trusted_Connection=True;";

               // var connectionstring = ConfigurationManager.AppSettings["SqlConnection"];               
                sqlConnection = new SqlConnection(connectionString);
                await sqlConnection.OpenAsync();
                SqlCommand sqlcommand = new SqlCommand("SelectStudentsByClass", sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlcommand.Parameters.Add("@classID", SqlDbType.Int).Value = id;
                DataTable tablestudent = new DataTable();
                tablestudent.Load(await sqlcommand.ExecuteReaderAsync());

           

                List<Student> studentList = new List<Student>();
                tablestudent.AsEnumerable();

                for (int i = 0; i < tablestudent.Rows.Count; i++)
                {
                    var row = tablestudent.Rows[i];

                    var temp = new Student()
                    {
                        Id = Convert.ToInt32(row["Id"]),
                        Name = row["Name"].ToString(),
                        Age = Convert.ToInt32(row["Age"])
                    };

                    studentList.Add(temp);
                }


                //studentList = (from DataRow dr in tablestudent.Select()
                //               select new Student()
                //               {
                //                   Id = Convert.ToInt32(dr["Id"]),
                //                   Name = dr["Name"].ToString(),
                //                   Age = Convert.ToInt32(dr["Age"])
                //                 //  Class = dr["MobileNo"].ToString()
                //               }).ToList();

                await sqlConnection.CloseAsync();
                return studentList;
            }
            catch(Exception ex)
            {

            }
            return null;
        }

        public async Task<Student> GetByIdAsync(int id)
        {
            try
            {
                string connectionString = "Server=DESKTOP-OUCK1GJ\\SQLEXPRESS;Database=SchoolManagement;Trusted_Connection=True;";

                // var connectionstring = ConfigurationManager.AppSettings["SqlConnection"];               
                sqlConnection = new SqlConnection(connectionString);
                await sqlConnection.OpenAsync();
                SqlCommand sqlcommand = new SqlCommand("GetStudentByID", sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlcommand.Parameters.Add("@Id", SqlDbType.Int).Value = id;

                SqlDataReader sqlDataReader = await sqlcommand.ExecuteReaderAsync();
               // DataTable dt = new DataTable();


              //  dt.Load(await sqlcommand.ExecuteReaderAsync());

                Student student = new Student();
                if (sqlDataReader.Read())
                {

                    student.Id = Convert.ToInt32(sqlDataReader["Id"]);
                    student.Name = Convert.ToString(sqlDataReader["Name"]);
                    student.Age = Convert.ToInt32(sqlDataReader["Age"]);

                    student.Birthdate = Convert.ToDateTime (sqlDataReader["BirthDate"]);

                }
                await sqlConnection.CloseAsync();
                return await Task.FromResult(student);
          
            }
            catch(Exception ex)
            {
                return null;
            }
         
        }
        public async Task<Student> Update(Student Tentity)
        {

            try
            {
                string connectionString = "Server=DESKTOP-OUCK1GJ\\SQLEXPRESS;Database=SchoolManagement;Trusted_Connection=True;";

                // var connectionstring = ConfigurationManager.AppSettings["SqlConnection"];               
                sqlConnection = new SqlConnection(connectionString);
                await sqlConnection.OpenAsync();
                SqlCommand sqlcommand = new SqlCommand("UpdateStudent", sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlcommand.Parameters.Add("@Id", SqlDbType.Int).Value = Tentity.Id;
                sqlcommand.Parameters.Add("@Name", SqlDbType.Text).Value = Tentity.Name;
                sqlcommand.Parameters.Add("@Age", SqlDbType.Int).Value = Tentity.Age;
                sqlcommand.Parameters.Add("@BirthDate", SqlDbType.DateTime).Value = Tentity.Birthdate;

                var k = await sqlcommand.ExecuteNonQueryAsync();
                // DataTable dt = new DataTable();


                //  dt.Load(await sqlcommand.ExecuteReaderAsync());

                Student student = new Student();
             
                await sqlConnection.CloseAsync();
                return await Task.FromResult(student);

            }
            catch (Exception ex)
            {
                return null;
            }

        }
    }
}
