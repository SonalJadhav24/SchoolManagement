﻿using Microsoft.Extensions.Configuration;
using School.Management.Core;
using School.Management.Core.Entities;
using School.Management.Core.Repository;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;

namespace School.Management.Data
{
    public class TeacherRepository : ITeacherRepository
    {
       
        //public TeacherRepository()
        //{
        //    //Open the configuration file using the dll location
        //    Configuration myDllConfig =
        //           ConfigurationManager.OpenExeConfiguration(this.GetType().Assembly.Location);
        //    // Get the appSettings section
        //    ConnectionStringsSection myDllConfigAppSettings =
        //           (ConnectionStringsSection)myDllConfig.GetSection("connectionStrings");
        //    // return the desired field 

        //    var val = myDllConfigAppSettings.ConnectionStrings["SQLDBConnection"];
        //    this.ConnectionString = val.ToString();
        //}

        SqlConnection sqlConnection = null;
      
        public Task<Teacher> Add(Teacher TEntity)
        {
            throw new NotImplementedException();
        }

        public Task<Teacher> Delete(int TEntity)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
          
        }

        public async Task<List<Teacher>> GetAllAsync(int id)
        {
            try
            {
                sqlConnection = new SqlConnection("Server=DESKTOP-OUCK1GJ\\SQLEXPRESS;Database=SchoolManagement;Trusted_Connection=True;");
                await sqlConnection.OpenAsync();
                SqlCommand sqlcommand = new SqlCommand("GetTeachersAll", sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };
                DataTable table = new DataTable();
                table.Load(await sqlcommand.ExecuteReaderAsync());
                List<Teacher> teachers = new List<Teacher>();

                for (int i = 0; i < table.Rows.Count; i++)
                {
                    var row = table.Rows[i];
                    var temp = new Teacher()
                    {
                        TeacherID = Convert.ToInt32(row["Id"]),
                        Name = row["Name"].ToString(),
                    };
                    teachers.Add(temp);
                }
                await sqlConnection.CloseAsync();
                return teachers;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public async Task<Teacher> GetByIdAsync(int id)
        {
            try
            {
                string connectionString = "Server=DESKTOP-OUCK1GJ\\SQLEXPRESS;Database=SchoolManagement;Trusted_Connection=True;";
                // var connectionstring = ConfigurationManager.AppSettings["SqlConnection"];               
                sqlConnection = new SqlConnection(connectionString);
                await sqlConnection.OpenAsync();
                SqlCommand sqlcommand = new SqlCommand();
                DataSet dtset = new DataSet();
                SqlDataAdapter dataAdapter = new SqlDataAdapter();
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    using (SqlCommand cmd = new SqlCommand("GetTeacherByID", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        SqlParameter sqlParameter = new SqlParameter
                        {
                            ParameterName = "@ClassId",
                            Value = id,
                            DbType = DbType.Int32
                        };
                        cmd.Parameters.Add(sqlParameter);
                    }
                }
                await sqlConnection.CloseAsync();
                return null; ;
            }
            catch (Exception ex)
            {
                return null;

            }
        }

        public Task<Student> Update(Teacher TEntity)
        {
            throw new NotImplementedException();
        }

        Task<Teacher> IRespository<Teacher>.Update(Teacher TEntity)
        {
            throw new NotImplementedException();
        }
    }

}
