﻿using School.Management.Core.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace School.Management.Data
{
    public class SubjectRepository : Core.Repository.ISubjectRepository
    {
        SqlConnection sqlConnection = null;
        public async Task<Subject> Add(Subject TEntity)
        {
            try
            {
                string connectionString = "Server=DESKTOP-OUCK1GJ\\SQLEXPRESS;Database=SchoolManagement;Trusted_Connection=True;";
                // var connectionstring = ConfigurationManager.AppSettings["SqlConnection"];               
                sqlConnection = new SqlConnection(connectionString);
                await sqlConnection.OpenAsync();
                SqlCommand sqlcommand = new SqlCommand("CreateSubject", sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlcommand.Parameters.Add("@Name", SqlDbType.Text).Value = TEntity.SubjectName;
                SqlParameter RuturnValue = sqlcommand.CreateParameter();
                RuturnValue.Direction = ParameterDirection.ReturnValue;
                sqlcommand.Parameters.Add(RuturnValue);

              var newsubjectid =   await sqlcommand.ExecuteReaderAsync();
                int id = (int)RuturnValue.Value;
                await newsubjectid.CloseAsync();


                 var selectedclasses = (from singleclass in TEntity.classes
                             where singleclass.Selected.Equals(true)
                             select singleclass).ToList();

                foreach(Class class_ in selectedclasses)
                {
                    SqlCommand sqlcommand1 = new SqlCommand("InsertSubjectClassRelRecord", sqlConnection)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    sqlcommand1.Parameters.Add("@ClassId", SqlDbType.Int).Value = class_.ClassID;
                    sqlcommand1.Parameters.Add("@SubjectId", SqlDbType.Int).Value = id;
                    await sqlcommand1.ExecuteNonQueryAsync();
                }

               await sqlConnection.CloseAsync();
               return new Subject ();

               
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        public async Task<Subject> Delete(int id)
        {
            try
            {
                string connectionString = "Server=DESKTOP-OUCK1GJ\\SQLEXPRESS;Database=SchoolManagement;Trusted_Connection=True;";

                // var connectionstring = ConfigurationManager.AppSettings["SqlConnection"];               
                sqlConnection = new SqlConnection(connectionString);
                await sqlConnection.OpenAsync();
                SqlCommand sqlcommand = new SqlCommand("DeleteSubject", sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlcommand.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                var p = await sqlcommand.ExecuteReaderAsync();



                await sqlConnection.CloseAsync();
                return new Subject();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public void Dispose()
        {
         
        }

        public async Task<List<Subject>> GetAllAsync(int id)
        {
            // Get all subjects  
            try
            {
                string connectionString = "Server=DESKTOP-OUCK1GJ\\SQLEXPRESS;Database=SchoolManagement;Trusted_Connection=True;";
                // var connectionstring = ConfigurationManager.AppSettings["SqlConnection"];               
                sqlConnection = new SqlConnection(connectionString);
                await sqlConnection.OpenAsync();
                SqlCommand sqlcommand = new SqlCommand("SelectSubjectsByClass", sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlcommand.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                DataTable table = new DataTable();
                table.Load(await sqlcommand.ExecuteReaderAsync());
                List<Subject> subjects = new List<Subject>();
           
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    var row = table.Rows[i];
                    var temp = new Subject()
                    {
                        SubjectID = Convert.ToInt32(row["Id"]),
                        SubjectName = row["Name"].ToString(),                      
                    };
                    subjects.Add(temp);
                }
                await sqlConnection.CloseAsync();
                return subjects;
            }
            catch (Exception ex)
            {
                return null;
            }         
        }

        public async Task<Subject> GetByIdAsync(int id)
        {
            try
            {
                string connectionString = "Server=DESKTOP-OUCK1GJ\\SQLEXPRESS;Database=SchoolManagement;Trusted_Connection=True;";
                // var connectionstring = ConfigurationManager.AppSettings["SqlConnection"];               
                sqlConnection = new SqlConnection(connectionString);
                await sqlConnection.OpenAsync();
                SqlCommand sqlcommand = new SqlCommand();
                DataSet dtset = new DataSet();
                SqlDataAdapter dataAdapter = new SqlDataAdapter();
                DataTable dt = new DataTable();
                  using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        con.Open();

                        using (SqlCommand cmd = new SqlCommand("GetSubjectById", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;

                        SqlParameter sqlParameter = new SqlParameter
                        {
                            ParameterName = "@ClassId",
                            Value = id,
                            DbType = DbType.Int32
                        };
                        cmd.Parameters.Add(sqlParameter);
                          
                            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                            {

                                    da.Fill(dtset);
                            }
                        }
                    }

                Subject subject = null;
             
        
                if (dtset.Tables[0] != null)
                {
                     subject = new Subject()
                        {
                            SubjectID = Convert.ToInt32(dtset.Tables[0].Rows[0].ItemArray[0]),
                            SubjectName = Convert.ToString(dtset.Tables[0].Rows[0].ItemArray[1].ToString())
                        };

                    if(dtset.Tables[1]!=null)
                    {
                        subject.classes = new List<Class>();
                        foreach(DataRow r  in dtset.Tables[1].Rows)
                        {
                            subject.classes.Add(new Class()
                            {
                                ClassID =  Convert.ToInt32(  r.ItemArray[0]),
                                ClassName = r.ItemArray[1].ToString()
                            });
                        }
                    }
                }
                await sqlConnection.CloseAsync();
                return subject;
            }
            catch (Exception ex)
            {
                return null;

            }
        }

        public async Task<Subject> Update(Subject TEntity)
        {

            try
            {
                string connectionString = "Server=DESKTOP-OUCK1GJ\\SQLEXPRESS;Database=SchoolManagement;Trusted_Connection=True;";

                // var connectionstring = ConfigurationManager.AppSettings["SqlConnection"];               
                sqlConnection = new SqlConnection(connectionString);
                await sqlConnection.OpenAsync();
                SqlCommand sqlcommand = new SqlCommand("UpdateSubject", sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlcommand.Parameters.Add("@Id", SqlDbType.Int).Value = TEntity.SubjectID;
                sqlcommand.Parameters.Add("@Name", SqlDbType.Text).Value = TEntity.SubjectName;
         
                var k = await sqlcommand.ExecuteNonQueryAsync();
              
                Subject subject = new Subject();

                await sqlConnection.CloseAsync();
                return await Task.FromResult(subject);

            }
            catch(Exception ex)
            {
                return null;
            }
        }
    }
}
