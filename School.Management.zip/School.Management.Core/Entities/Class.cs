﻿using System;
using System.Collections.Generic;
using System.Text;

namespace School.Management.Core.Entities
{
    public class Class
    {
        public int ClassID { get; set; }
        public string ClassName { get; set; }
        public bool Selected { get; set; }

       
    }
}
