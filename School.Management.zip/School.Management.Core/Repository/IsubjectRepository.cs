﻿using System;
using System.Collections.Generic;
using System.Text;

namespace School.Management.Core.Repository
{
    public interface ISubjectRepository : IRespository<Entities.Subject>
    {
    }
}
