﻿using System;
using System.Collections.Generic;
using System.Text;

namespace School.Management.Core.Repository
{
    public interface ITeacherRepository : IRespository<School.Management.Core.Entities.Teacher>
    {
    }
}
